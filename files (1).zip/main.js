// Mobile nav toggle
const burger = document.querySelector('.nav-burger');
const menu = document.querySelector('.nav-menu');
if (burger && menu) {
  burger.addEventListener('click', () => menu.classList.toggle('open'));
  menu.querySelectorAll('a').forEach(a => a.addEventListener('click', () => menu.classList.remove('open')));
}
