# Aron Henriquez — Personal Website

Minimal personal portfolio and blog. Text-first, no frameworks, no build step.

## Structure

```
index.html          ← Home
about.html          ← About me
experience.html     ← Full CV / career history
blog.html           ← Blog listing
blog/
  post-1.html
  post-2.html
  post-3.html
css/style.css
js/main.js
```

## Live site (GitHub Pages)

1. Go to repo **Settings → Pages**
2. Source: **Deploy from a branch → main → / (root)**
3. Save — live at `https://<username>.github.io/professional-portfolio/`

## Adding a blog post

1. Copy any file in `blog/` and rename it (e.g. `post-4.html`)
2. Edit the title, date, and content inside
3. Add a link to it in `blog.html` and `index.html`
